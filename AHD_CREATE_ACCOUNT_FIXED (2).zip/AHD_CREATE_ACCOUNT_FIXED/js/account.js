
/* =========================================================
   AHD ACCOUNT SYSTEM
   Connected with IndexedDB Authentication
   No localStorage
   No sessionStorage
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    async function () {

        try {

            const user =
                await AHDAuth.getUser();

            /* =================================================
               USER LOGIN CHECK
               ================================================= */

            if (!user) {

                showLoginRequired();

                return;
            }


            /* =================================================
               LOAD ACCOUNT
               ================================================= */

            loadAccount(user);

        } catch (error) {

            console.error(
                "Account loading error:",
                error
            );

            showLoginRequired();
        }
    }
);


/* =========================================================
   LOAD CURRENT USER ACCOUNT
   ========================================================= */

function loadAccount(user) {

    if (!user) return;


    const seller =
        user.role === "seller";


    /* =================================================
       BASIC USER INFORMATION
       ================================================= */

    setText(
        "profileName",
        user.name || "AHD User"
    );


    setText(
        "infoName",
        user.name || "AHD User"
    );


    setText(
        "infoMobile",
        user.phone || "Not available"
    );


    setText(
        "infoEmail",
        user.email || "Not available"
    );


    setText(
        "infoAccountType",
        seller ? "Seller" : "Customer"
    );


    setText(
        "profileType",
        seller
            ? "Seller Account"
            : "Customer Account"
    );


    /* =================================================
       LOCATION
       ================================================= */

    const location =
        user.location ||
        "Agra, Uttar Pradesh";


    setText(
        "infoLocation",
        location
    );


    setText(
        "userLocation",
        location
    );


    /* =================================================
       MEMBER SINCE
       ================================================= */

    let memberYear =
        "2026";


    if (user.createdAt) {

        const date =
            new Date(
                user.createdAt
            );


        if (!isNaN(date.getTime())) {

            memberYear =
                date.getFullYear();
        }
    }


    setText(
        "memberSince",
        memberYear
    );


    /* =================================================
       PROFILE PHOTO
       IMPORTANT:
       account.html mein profilePhoto DIV hai
       ================================================= */

    const profilePhoto =
        document.getElementById(
            "profilePhoto"
        );


    if (profilePhoto) {

        if (user.profilePhoto) {

            profilePhoto.style.backgroundImage =
                `url("${user.profilePhoto}")`;

            profilePhoto.style.backgroundSize =
                "cover";

            profilePhoto.style.backgroundPosition =
                "center";

            profilePhoto.style.backgroundRepeat =
                "no-repeat";

            profilePhoto.textContent = "";

        } else {

            profilePhoto.style.backgroundImage =
                "none";

            profilePhoto.textContent =
                "👤";
        }
    }


    /* =================================================
       CUSTOMER / SELLER SECTION
       ================================================= */

    const customerSection =
        document.getElementById(
            "customerSection"
        );


    const sellerSection =
        document.getElementById(
            "sellerSection"
        );


    if (customerSection) {

        customerSection.style.display =
            seller
                ? "none"
                : "block";
    }


    if (sellerSection) {

        sellerSection.style.display =
            seller
                ? "block"
                : "none";
    }


    /* =================================================
       ACCOUNT STATS (Dynamic Calculation)
       ================================================= */

    setText("purchaseCount", "0");
    setText("sellingCount", "0");
    setText("savedCount", "0");
    setText("requestCount", "0");

    if (window.AHDApi) {
        window.AHDApi.getProducts().then(products => {
            if (Array.isArray(products)) {
                const userListings = products.filter(p =>
                    p.seller?.email === user.email || p.seller?.phone === user.phone
                );
                setText("sellingCount", String(userListings.length));
            }
        }).catch(() => {});

        window.AHDApi.dbGetAll("requests").then(reqs => {
            if (Array.isArray(reqs)) {
                setText("requestCount", String(reqs.length));
            }
        }).catch(() => {});

        window.AHDApi.getDeals(user.email).then(deals => {
            if (Array.isArray(deals)) {
                setText("purchaseCount", String(deals.length));
            }
        }).catch(() => {});
    }
}


/* =========================================================
   LOGIN REQUIRED
   ========================================================= */

function showLoginRequired() {

    document.body.innerHTML = `

        <main style="
            min-height:100vh;
            display:flex;
            align-items:center;
            justify-content:center;
            background:#f5f7fb;
            padding:20px;
            font-family:Arial,sans-serif;
        ">

            <section style="
                width:100%;
                max-width:420px;
                background:#fff;
                border-radius:20px;
                padding:35px;
                text-align:center;
                box-shadow:0 15px 40px rgba(0,0,0,.08);
            ">

                <div style="font-size:50px">
                    🔐
                </div>

                <h1>
                    Login Required
                </h1>

                <p style="
                    color:#6b7280;
                    line-height:1.6;
                ">
                    Please login or signup to
                    access your AHD account.
                </p>

                <button
                    onclick="goLogin()"
                    style="
                        width:100%;
                        padding:14px;
                        border:0;
                        border-radius:10px;
                        background:#2563eb;
                        color:#fff;
                        font-weight:700;
                        cursor:pointer;
                    "
                >
                    Login / Signup
                </button>

            </section>

        </main>
    `;
}


/* =========================================================
   GO LOGIN
   ========================================================= */

function goLogin() {

    window.location.href =
        "login.html";
}


/* =========================================================
   EDIT PROFILE
   ========================================================= */

async function editProfile() {

    const user =
        await AHDAuth.getUser();


    if (!user) {

        window.location.href =
            "login.html";

        return;
    }


    window.location.href =
        "edit-profile.html";
}


/* =========================================================
   PROFILE PHOTO
   ========================================================= */

async function changeProfilePhoto() {

    const user =
        await AHDAuth.getUser();


    if (!user) {

        window.location.href =
            "login.html";

        return;
    }


    window.location.href =
        "edit-profile.html";
}


/* =========================================================
   CHANGE PROFILE PHOTO
   ========================================================= */

function selectProfilePhoto() {

    const input =
        document.getElementById(
            "profilePhoto"
        );


    if (input) {

        input.click();
    }
}


/* =========================================================
   REMOVE PROFILE PHOTO
   ========================================================= */

async function removeProfilePhoto() {

    const user =
        await AHDAuth.getUser();


    if (!user) {

        window.location.href =
            "login.html";

        return;
    }


    const preview =
        document.getElementById(
            "profilePhotoPreview"
        );


    if (preview) {

        preview.src =
            "images/default-profile.png";
    }


    const input =
        document.getElementById(
            "profilePhoto"
        );


    if (input) {

        input.value = "";
    }


    window.removeProfilePhotoFlag =
        true;


    showMessage(
        "Profile photo removed. Click Save Changes to confirm.",
        "success"
    );
}


/* =========================================================
   SETTINGS
   ========================================================= */

async function openSettings() {

    const user =
        await AHDAuth.getUser();


    if (!user) {

        goLogin();

        return;
    }


    window.location.href =
        "settings.html";
}


/* =========================================================
   CUSTOMER FUNCTIONS
   ========================================================= */

function openPurchases() {

    alert(
        "My Purchases will be connected with the AHD database."
    );
}


function openSavedProducts() {

    alert(
        "Saved Products will be connected with the AHD database."
    );
}


function openRequests() {

    window.location.href =
        "request.html";
}


/* =========================================================
   SELLER FUNCTIONS
   ========================================================= */

function openMyListings() {

    window.location.href =
        "sell.html";
}


async function openSellerProfile() {

    const user =
        await AHDAuth.getUser();


    if (!user) {

        goLogin();

        return;
    }


    const q =
        new URLSearchParams({

            seller:
                user.email ||
                "current",

            role:
                user.role ||
                "seller",

            name:
                user.name ||
                "AHD Seller"
        });


    window.location.href =
        "seller-profile.html?" +
        q.toString();
}


/* =========================================================
   OTHER ACCOUNT FUNCTIONS
   ========================================================= */

function openMessagesPage() {

    window.location.href =
        "messages.html";
}


function openNotifications() {

    window.location.href =
        "notifications.html";
}


function openMatches() {
    window.location.href = "matches.html";
}


function openSellPage() {

    window.location.href =
        "sell.html";
}


function openDealPage() {
    window.location.href = "deal.html";
}


function openServices() {

    window.location.href =
        "services.html";
}


function openJobs() {

    window.location.href =
        "jobs.html";
}


function openWorkerProfile() {
    window.location.href = "worker-profile.html";
}


function openWorkerMatches() {

    alert(
        "Worker Matches will be connected with the AHD database."
    );
}


/* =========================================================
   LOGOUT
   ========================================================= */

async function logoutAccount() {

    const confirmLogout =
        confirm(
            "Are you sure you want to logout?"
        );


    if (!confirmLogout) return;


    try {

        await AHDAuth.logout();

    } catch (error) {

        console.error(
            "Logout error:",
            error
        );


        alert(
            "Unable to logout. Please try again."
        );
    }
}


/* =========================================================
   BUILD AUTH QUERY
   ========================================================= */

async function buildAuthQuery() {

    const user =
        await AHDAuth.getUser();


    if (!user) return "";


    return "?" +
        new URLSearchParams({

            auth:
                "1",

            role:
                user.role ||
                "customer",

            name:
                user.name ||
                "AHD User",

            email:
                user.email ||
                "",

            phone:
                user.phone ||
                "",

            location:
                user.location ||
                "Agra, Uttar Pradesh"

        }).toString();
}


/* =========================================================
   MESSAGE
   ========================================================= */

function showMessage(
    text,
    type
) {

    const message =
        document.getElementById(
            "editProfileMessage"
        );


    if (!message) return;


    message.textContent =
        text;


    message.className =
        "message " + type;
}


/* =========================================================
   SET TEXT
   ========================================================= */

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;
    }
}
