
/* =========================================================
   AHD SIGNUP SYSTEM

   Customer Signup
   Seller Signup

   Signup → Automatic Login → Account

   No localStorage
   No sessionStorage
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const DEMO_OTP = "123456";


        /* =================================================
           NAVIGATION BUTTONS
           ================================================= */

        const customerButton =
            document.getElementById(
                "customerSignupButton"
            );

        const sellerButton =
            document.getElementById(
                "sellerSignupButton"
            );

        const loginButton =
            document.getElementById(
                "loginButton"
            );

        const backButton =
            document.getElementById(
                "backHomeButton"
            );


        if (customerButton) {

            customerButton.addEventListener(
                "click",
                function () {

                    window.location.href =
                        "customer-signup.html";
                }
            );
        }


        if (sellerButton) {

            sellerButton.addEventListener(
                "click",
                function () {

                    window.location.href =
                        "seller-signup.html";
                }
            );
        }


        if (loginButton) {

            loginButton.addEventListener(
                "click",
                function () {

                    window.location.href =
                        "login.html";
                }
            );
        }


        if (backButton) {

            backButton.addEventListener(
                "click",
                function () {

                    window.location.href =
                        "index.html";
                }
            );
        }


        /* =================================================
           CUSTOMER SIGNUP
           ================================================= */

        const customerForm =
            document.getElementById(
                "customerSignupForm"
            );


        if (customerForm) {

            customerForm.addEventListener(
                "submit",
                async function (event) {

                    event.preventDefault();


                    const name =
                        document
                            .getElementById(
                                "customerName"
                            )
                            .value
                            .trim();


                    const phone =
                        document
                            .getElementById(
                                "customerPhone"
                            )
                            .value
                            .trim();


                    const phoneOtp =
                        document
                            .getElementById(
                                "customerPhoneOtp"
                            )
                            .value
                            .trim();


                    const email =
                        document
                            .getElementById(
                                "customerEmail"
                            )
                            .value
                            .trim();


                    const emailOtp =
                        document
                            .getElementById(
                                "customerEmailOtp"
                            )
                            .value
                            .trim();


                    const password =
                        document
                            .getElementById(
                                "customerPassword"
                            )
                            .value;


                    const confirmPassword =
                        document
                            .getElementById(
                                "customerConfirmPassword"
                            )
                            .value;


                    await createAccount({

                        name,

                        phone,

                        phoneOtp,

                        email,

                        emailOtp,

                        password,

                        confirmPassword,

                        role: "customer"
                    });
                }
            );
        }


        /* =================================================
           SELLER SIGNUP
           ================================================= */

        const sellerForm =
            document.getElementById(
                "sellerSignupForm"
            );


        if (sellerForm) {

            sellerForm.addEventListener(
                "submit",
                async function (event) {

                    event.preventDefault();


                    const name =
                        document
                            .getElementById(
                                "sellerName"
                            )
                            .value
                            .trim();


                    const phone =
                        document
                            .getElementById(
                                "sellerPhone"
                            )
                            .value
                            .trim();


                    const phoneOtp =
                        document
                            .getElementById(
                                "sellerPhoneOtp"
                            )
                            .value
                            .trim();


                    const email =
                        document
                            .getElementById(
                                "sellerEmail"
                            )
                            .value
                            .trim();


                    const emailOtp =
                        document
                            .getElementById(
                                "sellerEmailOtp"
                            )
                            .value
                            .trim();


                    const password =
                        document
                            .getElementById(
                                "sellerPassword"
                            )
                            .value;


                    const confirmPassword =
                        document
                            .getElementById(
                                "sellerConfirmPassword"
                            )
                            .value;


                    await createAccount({

                        name,

                        phone,

                        phoneOtp,

                        email,

                        emailOtp,

                        password,

                        confirmPassword,

                        role: "seller"
                    });
                }
            );
        }


        /* =================================================
           CREATE ACCOUNT
           ================================================= */

        async function createAccount(data) {

            const message =
                document.getElementById(
                    "signupMessage"
                );


            /* REQUIRED FIELDS */

            if (
                !data.name ||
                !data.phone ||
                !data.email ||
                !data.password
            ) {

                showMessage(
                    message,
                    "Please fill all details.",
                    "error"
                );

                return;
            }


            /* PHONE */

            if (
                !/^[0-9]{10}$/.test(
                    data.phone
                )
            ) {

                showMessage(
                    message,
                    "Enter a valid 10 digit phone number.",
                    "error"
                );

                return;
            }


            /* PHONE OTP */

            if (
                data.phoneOtp !==
                DEMO_OTP
            ) {

                showMessage(
                    message,
                    "Invalid Phone OTP. Demo OTP is 123456.",
                    "error"
                );

                return;
            }


            /* EMAIL OTP */

            if (
                data.emailOtp !==
                DEMO_OTP
            ) {

                showMessage(
                    message,
                    "Invalid Email OTP. Demo OTP is 123456.",
                    "error"
                );

                return;
            }


            /* PASSWORD LENGTH */

            if (
                data.password.length < 6
            ) {

                showMessage(
                    message,
                    "Password must contain at least 6 characters.",
                    "error"
                );

                return;
            }


            /* PASSWORD MATCH */

            if (
                data.password !==
                data.confirmPassword
            ) {

                showMessage(
                    message,
                    "Password and Confirm Password do not match.",
                    "error"
                );

                return;
            }


            /* =================================================
               SAVE ACCOUNT + AUTOMATIC LOGIN
               ================================================= */

            try {

                await AHDAuth.createAccount({

                    name:
                        data.name,

                    phone:
                        data.phone,

                    email:
                        data.email,

                    password:
                        data.password,

                    role:
                        data.role,

                    location:
                        "Agra, Uttar Pradesh"
                });


                /* SUCCESS MESSAGE */

                showMessage(
                    message,
                    "Account created successfully! Opening your account...",
                    "success"
                );


                /* =================================================
                   DIRECT ACCOUNT OPEN
                   User ko login page par dobara nahi bhejna.
                   ================================================= */

                setTimeout(
                    function () {

                        window.location.replace(
                            "account.html"
                        );

                    },
                    700
                );


            } catch (error) {

                showMessage(
                    message,
                    error.message ||
                    "Unable to create account.",
                    "error"
                );
            }
        }


        /* =================================================
           MESSAGE
           ================================================= */

        function showMessage(
            element,
            text,
            type
        ) {

            if (!element) return;


            element.textContent =
                text;


            element.className =
                "message " + type;
        }

    }
);

