/* =====================================================
   AHD HOME
   PRODUCT DISPLAY
===================================================== */


/*
    IMPORTANT:

    अभी कोई localStorage/sessionStorage नहीं है.

    फिलहाल frontend testing के लिए products
    इसी JavaScript array से दिख रहे हैं.

    बाद में यही data backend/database/API
    से आएगा.
*/


const ahdProducts = [

    {
        id: 1,
        name: "Premium Smartphone",
        price: 18999,
        category: "Mobiles",
        condition: "Good",
        location: "Agra",
        icon: "📱"
    },

    {
        id: 2,
        name: "Gaming Laptop",
        price: 52000,
        category: "Electronics",
        condition: "Excellent",
        location: "Agra",
        icon: "💻"
    },

    {
        id: 3,
        name: "Mountain Bicycle",
        price: 12500,
        category: "Sports",
        condition: "Good",
        location: "Firozabad",
        icon: "🚲"
    },

    {
        id: 4,
        name: "Study Table",
        price: 3200,
        category: "Furniture",
        condition: "Good",
        location: "Mathura",
        icon: "🪑"
    },

    {
        id: 5,
        name: "Smart LED TV",
        price: 24999,
        category: "Electronics",
        condition: "Excellent",
        location: "Agra",
        icon: "📺"
    },

    {
        id: 6,
        name: "Wireless Headphones",
        price: 1499,
        category: "Electronics",
        condition: "New",
        location: "Agra",
        icon: "🎧"
    },

    {
        id: 7,
        name: "Office Chair",
        price: 4500,
        category: "Furniture",
        condition: "Good",
        location: "Agra",
        icon: "💺"
    },

    {
        id: 8,
        name: "Smart Watch",
        price: 2999,
        category: "Mobiles",
        condition: "New",
        location: "Agra",
        icon: "⌚"
    }

];



/* =====================================================
   FORMAT PRICE
===================================================== */

function formatPrice(price) {

    return "₹" +
        Number(price).toLocaleString("en-IN");

}



/* =====================================================
   CREATE PRODUCT CARD
===================================================== */

function createProductCard(product) {

    return `

        <a
            href="product.html?id=${product.id}"
            class="product-card"
        >

            <div class="product-image">

                ${product.icon}

            </div>


            <div class="product-info">

                <div class="product-title">

                    ${product.name}

                </div>


                <div class="product-price">

                    ${formatPrice(product.price)}

                </div>


                <div class="product-location">

                    📍 ${product.location}

                </div>


                <div class="product-location">

                    ${product.condition}

                    • ${product.category}

                </div>

            </div>

        </a>

    `;

}



/* =====================================================
   LOAD PRODUCTS
===================================================== */

function loadHomeProducts() {

    const productContainer =
        document.getElementById("products");


    if (!productContainer) {

        return;

    }


    productContainer.innerHTML = "";


    ahdProducts.forEach(
        function (product) {

            productContainer.innerHTML +=
                createProductCard(product);

        }
    );

}



/* =====================================================
   INITIALIZE
===================================================== */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        loadHomeProducts();

    }
);