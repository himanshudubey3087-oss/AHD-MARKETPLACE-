/* =========================================================
   AHD MARKETPLACE
   API & STORAGE BRIDGE (js/api.js)

   ✔ REST API connectivity (http://localhost:5000/api)
   ✔ Graceful fallback to IndexedDB if backend is offline
   ✔ Zero localStorage
   ✔ Zero sessionStorage
   ========================================================= */

const AHDApi = (() => {

    const API_BASE = window.location.origin.includes(":5000") 
        ? "/api" 
        : "http://localhost:5000/api";

    const DB_NAME = "AHDMarketplaceDB";
    const DB_VERSION = 4; // Upgraded to support products, requests, deals stores

    /* =====================================================
       INDEXED DB HELPER
    ===================================================== */
    function openDb() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);

            request.onupgradeneeded = (event) => {
                const db = event.target.result;

                // Users store
                if (!db.objectStoreNames.contains("users")) {
                    const userStore = db.createObjectStore("users", { keyPath: "email" });
                    userStore.createIndex("phone", "phone", { unique: true });
                }

                // Current user session store
                if (!db.objectStoreNames.contains("currentUser")) {
                    db.createObjectStore("currentUser", { keyPath: "id" });
                }

                // Products store
                if (!db.objectStoreNames.contains("products")) {
                    db.createObjectStore("products", { keyPath: "id" });
                }

                // Requests store
                if (!db.objectStoreNames.contains("requests")) {
                    db.createObjectStore("requests", { keyPath: "requestId" });
                }

                // Deals store
                if (!db.objectStoreNames.contains("deals")) {
                    db.createObjectStore("deals", { keyPath: "dealId" });
                }
            };

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async function dbGet(storeName, key) {
        const db = await openDb();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(storeName, "readonly");
            const store = tx.objectStore(storeName);
            const req = store.get(key);
            req.onsuccess = () => resolve(req.result || null);
            req.onerror = () => reject(req.error);
        });
    }

    async function dbGetAll(storeName) {
        const db = await openDb();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(storeName, "readonly");
            const store = tx.objectStore(storeName);
            const req = store.getAll();
            req.onsuccess = () => resolve(req.result || []);
            req.onerror = () => reject(req.error);
        });
    }

    async function dbPut(storeName, item) {
        const db = await openDb();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(storeName, "readwrite");
            const store = tx.objectStore(storeName);
            const req = store.put(item);
            req.onsuccess = () => resolve(item);
            req.onerror = () => reject(req.error);
        });
    }

    /* =====================================================
       GENERIC FETCH WITH TIMEOUT
    ===================================================== */
    async function apiFetch(endpoint, options = {}) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 3500);

        try {
            const response = await fetch(`${API_BASE}${endpoint}`, {
                ...options,
                headers: {
                    "Content-Type": "application/json",
                    ...(options.headers || {})
                },
                signal: controller.signal
            });

            clearTimeout(timeoutId);
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || "API request failed.");
            }

            return data;
        } catch (err) {
            clearTimeout(timeoutId);
            throw err;
        }
    }

    /* =====================================================
       PUBLIC API METHODS
    ===================================================== */
    return {
        // DB utilities
        openDb,
        dbGet,
        dbGetAll,
        dbPut,

        // Server health
        async isServerAvailable() {
            try {
                await apiFetch("/health");
                return true;
            } catch (_) {
                return false;
            }
        },

        // AUTHENTICATION
        async register(userData) {
            try {
                const res = await apiFetch("/auth/register", {
                    method: "POST",
                    body: JSON.stringify(userData)
                });
                // Cache user in IndexedDB
                if (res.user) {
                    await dbPut("users", res.user);
                    await dbPut("currentUser", { id: 1, email: res.user.email, ...res.user });
                }
                return res;
            } catch (apiError) {
                console.warn("Backend unavailable, using client IndexedDB for register:", apiError.message);
                if (typeof AHDAuth !== "undefined") {
                    const localUser = await AHDAuth.createAccount(userData);
                    return { user: localUser, message: "Registered locally." };
                }
                throw apiError;
            }
        },

        async login(identifier, password, role) {
            try {
                const res = await apiFetch("/auth/login", {
                    method: "POST",
                    body: JSON.stringify({ identifier, password, role })
                });
                if (res.user) {
                    await dbPut("currentUser", { id: 1, email: res.user.email, ...res.user });
                }
                return res;
            } catch (apiError) {
                console.warn("Backend unavailable, using client IndexedDB for login:", apiError.message);
                if (typeof AHDAuth !== "undefined") {
                    const localUser = await AHDAuth.login(identifier, password, role);
                    return { user: localUser, message: "Logged in locally." };
                }
                throw apiError;
            }
        },

        async getCurrentUser() {
            if (typeof AHDAuth !== "undefined" && typeof AHDAuth.getUser === "function") {
                return await AHDAuth.getUser();
            }
            return await dbGet("currentUser", 1);
        },

        async logout() {
            if (typeof AHDAuth !== "undefined" && typeof AHDAuth.logout === "function") {
                return await AHDAuth.logout();
            }
            const db = await openDb();
            return new Promise((resolve, reject) => {
                const tx = db.transaction("currentUser", "readwrite");
                const store = tx.objectStore("currentUser");
                const req = store.delete(1);
                req.onsuccess = () => resolve(true);
                req.onerror = () => reject(req.error);
            });
        },

        async syncProfileToBackend(profileData) {
            try {
                return await apiFetch("/auth/profile", {
                    method: "POST",
                    body: JSON.stringify(profileData)
                });
            } catch (err) {
                console.warn("Backend profile sync note:", err.message);
                return null;
            }
        },

        async updateProfile(profileData) {
            if (typeof AHDAuth !== "undefined" && typeof AHDAuth.updateProfile === "function") {
                await AHDAuth.updateProfile(profileData);
            }
            return await this.syncProfileToBackend(profileData);
        },

        // PRODUCTS
        async getProducts(filters = {}) {
            try {
                const query = new URLSearchParams(filters).toString();
                const products = await apiFetch(`/products?${query}`);
                // Sync to local cache
                products.forEach(p => dbPut("products", p).catch(() => {}));
                return products;
            } catch (_) {
                const local = await dbGetAll("products");
                return local.length > 0 ? local : [];
            }
        },

        async getProductById(id) {
            try {
                const product = await apiFetch(`/products/${id}`);
                await dbPut("products", product);
                return product;
            } catch (_) {
                const local = await dbGet("products", String(id));
                return local;
            }
        },

        async createProduct(productData) {
            // Store in IndexedDB first so it survives immediate page navigation
            await dbPut("products", productData);

            try {
                const res = await apiFetch("/products", {
                    method: "POST",
                    body: JSON.stringify(productData)
                });
                if (res.product) {
                    await dbPut("products", res.product);
                    return res.product;
                }
            } catch (err) {
                console.warn("Backend unavailable, product saved in IndexedDB:", err.message);
            }
            return productData;
        },

        // REQUESTS
        async createRequest(requestData) {
            await dbPut("requests", requestData);

            try {
                const res = await apiFetch("/requests", {
                    method: "POST",
                    body: JSON.stringify(requestData)
                });
                if (res.request) {
                    await dbPut("requests", res.request);
                    return res.request;
                }
            } catch (err) {
                console.warn("Backend unavailable, request saved in IndexedDB:", err.message);
            }
            return requestData;
        },

        async getRequestById(requestId) {
            try {
                const req = await apiFetch(`/requests/${requestId}`);
                await dbPut("requests", req);
                return req;
            } catch (_) {
                return await dbGet("requests", String(requestId));
            }
        },

        // MATCHES
        async getMatches(requestId) {
            try {
                const res = await apiFetch(`/matches/${requestId}`);
                return res.matches || [];
            } catch (_) {
                return [];
            }
        },

        // DEALS
        async saveDeal(dealData) {
            await dbPut("deals", dealData);
            try {
                const res = await apiFetch("/deals", {
                    method: "POST",
                    body: JSON.stringify(dealData)
                });
                return res.deal || dealData;
            } catch (_) {
                return dealData;
            }
        },

        async getDeals(user) {
            try {
                return await apiFetch(`/deals?user=${encodeURIComponent(user || "")}`);
            } catch (_) {
                return await dbGetAll("deals");
            }
        }
    };
})();

// Attach globally
window.AHDApi = AHDApi;
