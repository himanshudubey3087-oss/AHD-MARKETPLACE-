/* =====================================================
   AHD LOCATION SYSTEM
===================================================== */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const locationText =
            document.querySelector(
                "[data-location]"
            );

        if (!locationText) {
            return;
        }


        if (!navigator.geolocation) {

            locationText.textContent =
                "Location not supported";

            return;

        }


        locationText.textContent =
            "Detecting your location...";


        navigator.geolocation.getCurrentPosition(

            function (position) {

                const latitude =
                    position.coords.latitude;

                const longitude =
                    position.coords.longitude;


                console.log(
                    "Latitude:",
                    latitude
                );

                console.log(
                    "Longitude:",
                    longitude
                );


                locationText.textContent =
                    "Nearby products";


                /*
                    IMPORTANT:

                    अभी coordinates सिर्फ frontend
                    में मिल रहे हैं.

                    Backend बनने के बाद:

                    latitude
                    longitude

                    को database/API में भेजकर
                    nearby products को पहले दिखाया जाएगा.
                */

            },


            function () {

                locationText.textContent =
                    "Location unavailable";

            }

        );

    }
);