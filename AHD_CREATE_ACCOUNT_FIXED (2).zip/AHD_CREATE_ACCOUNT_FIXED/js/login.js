/* =========================================================
   AHD MARKETPLACE
   CUSTOMER + SELLER LOGIN

   ONE LOGIN.JS FOR BOTH
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {


    /* =====================================================
       LOGIN SELECTION PAGE
       login.html
       ===================================================== */

    const customerLoginButton =
        document.getElementById(
            "customerLoginButton"
        );

    const sellerLoginButton =
        document.getElementById(
            "sellerLoginButton"
        );

    const createAccountButton =
        document.getElementById(
            "createAccountButton"
        );

    const backHomeButton =
        document.getElementById(
            "backHomeButton"
        );


    if (customerLoginButton) {

        customerLoginButton.addEventListener(
            "click",
            () => {

                window.location.href =
                    "customer-login.html";

            }
        );

    }


    if (sellerLoginButton) {

        sellerLoginButton.addEventListener(
            "click",
            () => {

                window.location.href =
                    "seller-login.html";

            }
        );

    }


    if (createAccountButton) {

        createAccountButton.addEventListener(
            "click",
            () => {

                window.location.href =
                    "signup.html";

            }
        );

    }


    if (backHomeButton) {

        backHomeButton.addEventListener(
            "click",
            () => {

                window.location.href =
                    "index.html";

            }
        );

    }



    /* =====================================================
       CUSTOMER LOGIN
       ===================================================== */

    const customerForm =
        document.getElementById(
            "customerLoginForm"
        );


    if (customerForm) {

        customerForm.addEventListener(
            "submit",
            async (event) => {

                event.preventDefault();

                await loginUser("customer");

            }
        );

    }



    /* =====================================================
       SELLER LOGIN
       ===================================================== */

    const sellerForm =
        document.getElementById(
            "sellerLoginForm"
        );


    if (sellerForm) {

        sellerForm.addEventListener(
            "submit",
            async (event) => {

                event.preventDefault();

                await loginUser("seller");

            }
        );

    }



    /* =====================================================
       CUSTOMER CREATE ACCOUNT
       ===================================================== */

    const customerCreateAccount =
        document.getElementById(
            "customerCreateAccount"
        );


    if (customerCreateAccount) {

        customerCreateAccount.addEventListener(
            "click",
            () => {

                window.location.href =
                    "customer-signup.html";

            }
        );

    }



    /* =====================================================
       SELLER CREATE ACCOUNT
       ===================================================== */

    const sellerCreateAccount =
        document.getElementById(
            "sellerCreateAccount"
        );


    if (sellerCreateAccount) {

        sellerCreateAccount.addEventListener(
            "click",
            () => {

                window.location.href =
                    "seller-signup.html";

            }
        );

    }



    /* =====================================================
       BACK HOME
       ===================================================== */

    const customerBackHome =
        document.getElementById(
            "customerBackHome"
        );


    const sellerBackHome =
        document.getElementById(
            "sellerBackHome"
        );


    if (customerBackHome) {

        customerBackHome.addEventListener(
            "click",
            () => {

                window.location.href =
                    "home.html";

            }
        );

    }


    if (sellerBackHome) {

        sellerBackHome.addEventListener(
            "click",
            () => {

                window.location.href =
                    "home.html";

            }
        );

    }



    /* =====================================================
       PASSWORD TOGGLE
       ===================================================== */

    const customerPasswordToggle =
        document.getElementById(
            "customerPasswordToggle"
        );


    const sellerPasswordToggle =
        document.getElementById(
            "sellerPasswordToggle"
        );


    if (customerPasswordToggle) {

        customerPasswordToggle.addEventListener(
            "click",
            () => {

                togglePassword(
                    "customerPassword",
                    customerPasswordToggle
                );

            }
        );

    }


    if (sellerPasswordToggle) {

        sellerPasswordToggle.addEventListener(
            "click",
            () => {

                togglePassword(
                    "sellerPassword",
                    sellerPasswordToggle
                );

            }
        );

    }



    /* =====================================================
       FORGOT PASSWORD
       CUSTOMER

       IMPORTANT:
       from=customer
       ===================================================== */

    const customerForgotPassword =
        document.getElementById(
            "customerForgotPassword"
        );


    if (customerForgotPassword) {

        customerForgotPassword.addEventListener(
            "click",
            (event) => {

                event.preventDefault();


                window.location.href =
                    "forgot-password.html?from=customer";

            }
        );

    }



    /* =====================================================
       FORGOT PASSWORD
       SELLER

       IMPORTANT:
       from=seller
       ===================================================== */

    const sellerForgotPassword =
        document.getElementById(
            "sellerForgotPassword"
        );


    if (sellerForgotPassword) {

        sellerForgotPassword.addEventListener(
            "click",
            (event) => {

                event.preventDefault();


                window.location.href =
                    "forgot-password.html?from=seller";

            }
        );

    }



    /* =====================================================
       LOGIN FUNCTION
       ===================================================== */

    async function loginUser(role) {

        let identifier;
        let password;
        let message;
        let button;


        /* =================================================
           CUSTOMER
        ================================================= */

        if (role === "customer") {

            const identifierInput =
                document.getElementById(
                    "customerEmail"
                );

            const passwordInput =
                document.getElementById(
                    "customerPassword"
                );


            identifier =
                identifierInput
                    ? identifierInput.value.trim()
                    : "";


            password =
                passwordInput
                    ? passwordInput.value
                    : "";


            message =
                document.getElementById(
                    "customerLoginMessage"
                );


            button =
                document.getElementById(
                    "customerLoginSubmit"
                );

        }


        /* =================================================
           SELLER
        ================================================= */

        else {

            const identifierInput =
                document.getElementById(
                    "sellerEmail"
                );

            const passwordInput =
                document.getElementById(
                    "sellerPassword"
                );


            identifier =
                identifierInput
                    ? identifierInput.value.trim()
                    : "";


            password =
                passwordInput
                    ? passwordInput.value
                    : "";


            message =
                document.getElementById(
                    "sellerLoginMessage"
                );


            button =
                document.getElementById(
                    "sellerLoginSubmit"
                );

        }



        /* =================================================
           EMPTY CHECK
        ================================================= */

        if (!identifier) {

            showMessage(
                message,
                "Please enter your email or mobile number.",
                "error"
            );

            return;

        }


        if (!password) {

            showMessage(
                message,
                "Please enter your password.",
                "error"
            );

            return;

        }



        /* =================================================
           LOADING
        ================================================= */

        if (button) {

            button.disabled =
                true;


            button.dataset.originalText =
                button.textContent;


            button.textContent =
                "Logging in...";

        }



        /* =================================================
           LOGIN
        ================================================= */

        try {

            await AHDAuth.login(
                identifier,
                password,
                role
            );


            showMessage(
                message,
                "Login successful! Opening AHD...",
                "success"
            );


            setTimeout(
                () => {

                    window.location.replace(
                        "home.html"
                    );

                },
                350
            );

        }


        catch (error) {

            showMessage(
                message,
                error.message ||
                "Invalid email/phone or password.",
                "error"
            );


            if (button) {

                button.disabled =
                    false;


                button.textContent =
                    button.dataset.originalText ||
                    "Login";

            }

        }

    }



    /* =====================================================
       MESSAGE
       ===================================================== */

    function showMessage(
        element,
        text,
        type
    ) {

        if (!element) {

            return;

        }


        element.textContent =
            text;


        element.className =
            "message " + type;

    }



    /* =====================================================
       PASSWORD TOGGLE
       ===================================================== */

    window.togglePassword =
        function (
            inputId,
            button
        ) {

            const input =
                document.getElementById(
                    inputId
                );


            if (!input) {

                return;

            }


            if (
                input.type ===
                "password"
            ) {

                input.type =
                    "text";


                button.textContent =
                    "🙈";


                button.setAttribute(
                    "aria-label",
                    "Hide password"
                );

            }

            else {

                input.type =
                    "password";


                button.textContent =
                    "👁";


                button.setAttribute(
                    "aria-label",
                    "Show password"
                );

            }

        };

});