document.addEventListener("DOMContentLoaded", async () => {

    const backBtn = document.getElementById("backBtn");

    const profilePhoto = document.getElementById("profilePhoto");
    const photoButton = document.getElementById("photoButton");
    const photoInput = document.getElementById("photoInput");

    const userName = document.getElementById("userName");
    const userEmail = document.getElementById("userEmail");
    const userRole = document.getElementById("userRole");

    const editProfileBtn = document.getElementById("editProfileBtn");
    const serviceProfileBtn = document.getElementById("serviceProfileBtn");
    const changePasswordBtn = document.getElementById("changePasswordBtn");

    const notificationToggle =
        document.getElementById("notificationToggle");

    const locationBtn = document.getElementById("locationBtn");
    const locationValue = document.getElementById("locationValue");

    const helpBtn = document.getElementById("helpBtn");
    const aboutBtn = document.getElementById("aboutBtn");
    const logoutBtn = document.getElementById("logoutBtn");

    const locationModal =
        document.getElementById("locationModal");

    const closeLocationModal =
        document.getElementById("closeLocationModal");

    const locationInput =
        document.getElementById("locationInput");

    const saveLocationBtn =
        document.getElementById("saveLocationBtn");

    const aboutModal =
        document.getElementById("aboutModal");

    const closeAboutModal =
        document.getElementById("closeAboutModal");


    let currentUser = null;


    /* =====================================================
       LOAD CURRENT USER
    ===================================================== */

    try {

        if (typeof AHDAuth === "undefined") {

            throw new Error(
                "auth.js load nahi hua. Check karo auth.js aur settings.html same folder mein hain."
            );

        }

        currentUser = await AHDAuth.getUser();

        console.log("AHD CURRENT USER:", currentUser);


        if (!currentUser) {

            alert("Please login first.");

            window.location.replace("login.html");

            return;

        }


    } catch (error) {

        console.error(
            "SETTINGS ACCOUNT ERROR:",
            error
        );

        alert(
            "Unable to load account.\n\n" +
            "Error: " +
            (error.message || error)
        );

        return;
    }


    /* =====================================================
       LOAD USER DATA
    ===================================================== */

    function loadUserData() {

        if (!currentUser) return;


        const name =
            currentUser.name ||
            currentUser.fullName ||
            currentUser.serviceName ||
            "AHD User";


        userName.textContent = name;


        userEmail.textContent =
            currentUser.email || "";


        const role =
            String(
                currentUser.role || "customer"
            ).toLowerCase();


        if (role === "seller") {

            userRole.textContent =
                "Service Provider";

        } else {

            userRole.textContent =
                "Customer";

        }


        locationValue.textContent =
            currentUser.location ||
            "Agra, Uttar Pradesh";


        if (currentUser.profilePhoto) {

            profilePhoto.src =
                currentUser.profilePhoto;

        }


        notificationToggle.checked =
            currentUser.notificationsEnabled !== false;


        /*
         * Service Profile sirf seller ke liye
         */

        if (role !== "seller") {

            serviceProfileBtn.style.display = "none";

        }

    }


    loadUserData();


    /* =====================================================
       BACK
    ===================================================== */

    backBtn.addEventListener(
        "click",
        () => {

            if (window.history.length > 1) {

                window.history.back();

            } else {

                window.location.href =
                    "home.html";

            }

        }
    );


    /* =====================================================
       EDIT PROFILE
    ===================================================== */

    editProfileBtn.addEventListener(
        "click",
        () => {

            window.location.href =
                "edit-profile.html";

        }
    );


    /* =====================================================
       SERVICE PROFILE
    ===================================================== */

    serviceProfileBtn.addEventListener(
        "click",
        () => {

            if (
                !currentUser ||
                String(currentUser.role).toLowerCase() !== "seller"
            ) {

                alert(
                    "Service Profile is available for seller accounts."
                );

                return;

            }


            window.location.href =
                "seller-profile.html";

        }
    );


    /* =====================================================
       CHANGE PASSWORD
    ===================================================== */

    changePasswordBtn.addEventListener(
        "click",
        () => {

            const role =
                String(
                    currentUser.role || "customer"
                ).toLowerCase();


            const from =
                role === "seller"
                    ? "seller"
                    : "customer";


            const phone =
                currentUser.phone || "";


            window.location.href =
                "forgot-password.html?from=" +
                from +
                "&phone=" +
                encodeURIComponent(phone);

        }
    );


    /* =====================================================
       NOTIFICATIONS
    ===================================================== */

    notificationToggle.addEventListener(
        "change",
        async () => {

            try {

                await updateUserField(
                    "notificationsEnabled",
                    notificationToggle.checked
                );

                currentUser.notificationsEnabled =
                    notificationToggle.checked;

            } catch (error) {

                console.error(
                    "Notification update error:",
                    error
                );

                notificationToggle.checked =
                    !notificationToggle.checked;

                alert(
                    "Unable to update notification settings."
                );

            }

        }
    );


    /* =====================================================
       PROFILE PHOTO
    ===================================================== */

    photoButton.addEventListener(
        "click",
        () => {

            photoInput.click();

        }
    );


    photoInput.addEventListener(
        "change",
        async () => {

            const file =
                photoInput.files &&
                photoInput.files[0];


            if (!file) return;


            if (!file.type.startsWith("image/")) {

                alert(
                    "Please select a valid image."
                );

                return;

            }


            /*
             * Image size limit
             */

            if (file.size > 2 * 1024 * 1024) {

                alert(
                    "Profile photo 2 MB se chhoti honi chahiye."
                );

                photoInput.value = "";

                return;

            }


            const reader =
                new FileReader();


            reader.onload = async () => {

                const imageData =
                    reader.result;


                profilePhoto.src =
                    imageData;


                try {

                    await updateUserField(
                        "profilePhoto",
                        imageData
                    );


                    currentUser.profilePhoto =
                        imageData;


                } catch (error) {

                    console.error(
                        "Profile photo error:",
                        error
                    );


                    alert(
                        "Unable to save profile photo."
                    );

                }

            };


            reader.onerror = () => {

                alert(
                    "Unable to read selected image."
                );

            };


            reader.readAsDataURL(file);

        }
    );


    /* =====================================================
       LOCATION
    ===================================================== */

    locationBtn.addEventListener(
        "click",
        () => {

            locationInput.value =
                currentUser.location ||
                "Agra, Uttar Pradesh";


            locationModal.classList.add(
                "active"
            );


            setTimeout(
                () => locationInput.focus(),
                100
            );

        }
    );


    closeLocationModal.addEventListener(
        "click",
        closeLocation
    );


    saveLocationBtn.addEventListener(
        "click",
        async () => {

            const location =
                locationInput.value.trim();


            if (!location) {

                alert(
                    "Please enter your location."
                );

                return;

            }


            try {

                saveLocationBtn.disabled =
                    true;

                saveLocationBtn.textContent =
                    "Saving...";


                await updateUserField(
                    "location",
                    location
                );


                currentUser.location =
                    location;


                locationValue.textContent =
                    location;


                closeLocation();


            } catch (error) {

                console.error(
                    "Location error:",
                    error
                );

                alert(
                    "Unable to save location."
                );

            } finally {

                saveLocationBtn.disabled =
                    false;

                saveLocationBtn.textContent =
                    "Save Location";

            }

        }
    );


    function closeLocation() {

        locationModal.classList.remove(
            "active"
        );

    }


    /* =====================================================
       HELP
    ===================================================== */

    helpBtn.addEventListener(
        "click",
        () => {

            alert(
                "AHD Help & Support\n\n" +
                "For help with your account, products " +
                "or services, contact AHD support."
            );

        }
    );


    /* =====================================================
       ABOUT
    ===================================================== */

    aboutBtn.addEventListener(
        "click",
        () => {

            aboutModal.classList.add(
                "active"
            );

        }
    );


    closeAboutModal.addEventListener(
        "click",
        () => {

            aboutModal.classList.remove(
                "active"
            );

        }
    );


    aboutModal.addEventListener(
        "click",
        (event) => {

            if (
                event.target === aboutModal
            ) {

                aboutModal.classList.remove(
                    "active"
                );

            }

        }
    );


    locationModal.addEventListener(
        "click",
        (event) => {

            if (
                event.target === locationModal
            ) {

                closeLocation();

            }

        }
    );


    /* =====================================================
       LOGOUT
    ===================================================== */

    logoutBtn.addEventListener(
        "click",
        async () => {

            const confirmLogout =
                confirm(
                    "Are you sure you want to logout?"
                );


            if (!confirmLogout) return;


            try {

                await AHDAuth.logout();

            } catch (error) {

                console.error(
                    "Logout error:",
                    error
                );

                window.location.replace(
                    "index.html"
                );

            }

        }
    );


    /* =====================================================
       UPDATE USER FIELD
    ===================================================== */

    async function updateUserField(
        field,
        value
    ) {

        if (!currentUser || !currentUser.email) {

            throw new Error(
                "Current user not available."
            );

        }


        return new Promise(
            async (resolve, reject) => {

                try {

                    /*
                     * Existing AHD database open karo.
                     * Version specify nahi kar rahe, isliye
                     * existing DB version automatically use hoga.
                     */

                    const request =
                        indexedDB.open(
                            "AHDMarketplaceDB"
                        );


                    request.onerror =
                        () => {

                            reject(
                                request.error ||
                                new Error(
                                    "Unable to open AHD database."
                                )
                            );

                        };


                    request.onsuccess =
                        () => {

                            const db =
                                request.result;


                            let transaction;


                            try {

                                transaction =
                                    db.transaction(
                                        "users",
                                        "readwrite"
                                    );

                            } catch (error) {

                                db.close();

                                reject(error);

                                return;

                            }


                            const store =
                                transaction.objectStore(
                                    "users"
                                );


                            const getRequest =
                                store.get(
                                    currentUser.email
                                );


                            getRequest.onerror =
                                () => {

                                    reject(
                                        getRequest.error
                                    );

                                };


                            getRequest.onsuccess =
                                () => {

                                    const user =
                                        getRequest.result;


                                    if (!user) {

                                        reject(
                                            new Error(
                                                "User not found in database."
                                            )
                                        );

                                        return;

                                    }


                                    user[field] =
                                        value;


                                    user.updatedAt =
                                        new Date().toISOString();


                                    const putRequest =
                                        store.put(user);


                                    putRequest.onerror =
                                        () => {

                                            reject(
                                                putRequest.error
                                            );

                                        };

                                };


                            transaction.oncomplete =
                                () => {

                                    db.close();

                                    resolve(true);

                                };


                            transaction.onerror =
                                () => {

                                    db.close();

                                    reject(
                                        transaction.error
                                    );

                                };


                            transaction.onabort =
                                () => {

                                    db.close();

                                    reject(
                                        transaction.error ||
                                        new Error(
                                            "Database transaction aborted."
                                        )
                                    );

                                };

                        };

                } catch (error) {

                    reject(error);

                }

            }
        );

    }

});