const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DATA_DIR = path.join(__dirname, "data");

if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial seed products
const SEED_PRODUCTS = [
    {
        id: "P001",
        name: "Samsung Galaxy S23 256GB",
        price: 42000,
        category: "Mobiles",
        condition: "Like New",
        location: "Agra, Uttar Pradesh",
        description: "Samsung Galaxy S23 with Snapdragon 8 Gen 2. Like-new condition with bill, box, and charger. No scratches.",
        seller: {
            name: "Rahul Sharma",
            phone: "9876543210",
            email: "rahul@ahd.in",
            role: "seller"
        },
        images: [
            "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?auto=format&fit=crop&w=1000&q=80"
        ],
        rating: 4.7,
        status: "active",
        createdAt: new Date().toISOString()
    },
    {
        id: "P002",
        name: "iPhone 13 128GB",
        price: 38000,
        category: "Mobiles",
        condition: "Good",
        location: "Agra, Uttar Pradesh",
        description: "iPhone 13 128GB blue color. Battery health 87%. Display and camera in flawless condition.",
        seller: {
            name: "Aman Gupta",
            phone: "9823456781",
            email: "aman@ahd.in",
            role: "seller"
        },
        images: [
            "https://images.unsplash.com/photo-1592286927505-2fd4b5e8c2e7?auto=format&fit=crop&w=1000&q=80"
        ],
        rating: 4.6,
        status: "active",
        createdAt: new Date().toISOString()
    },
    {
        id: "P003",
        name: "Dell Inspiron 15 Core i5 Laptop",
        price: 35000,
        category: "Electronics",
        condition: "Good",
        location: "Agra, Uttar Pradesh",
        description: "11th Gen Core i5, 16GB RAM, 512GB SSD. Perfect for coding, office work, and daily browsing.",
        seller: {
            name: "Vikas Singh",
            phone: "9812345670",
            email: "vikas@ahd.in",
            role: "seller"
        },
        images: [
            "https://images.unsplash.com/photo-1593642532744-d377ab507dc8?auto=format&fit=crop&w=1000&q=80"
        ],
        rating: 4.5,
        status: "active",
        createdAt: new Date().toISOString()
    },
    {
        id: "P004",
        name: "HP Victus Gaming Laptop",
        price: 54000,
        category: "Electronics",
        condition: "Like New",
        location: "Mathura, Uttar Pradesh",
        description: "Ryzen 5 5600H, GTX 1650, 144Hz IPS display, 16GB RAM. Mint condition with original box.",
        seller: {
            name: "Rohit Kumar",
            phone: "9765432109",
            email: "rohit@ahd.in",
            role: "seller"
        },
        images: [
            "https://images.unsplash.com/photo-1603302576837-37561b2e2302?auto=format&fit=crop&w=1000&q=80"
        ],
        rating: 4.8,
        status: "active",
        createdAt: new Date().toISOString()
    },
    {
        id: "P005",
        name: "Solid Wooden Study Table & Chair",
        price: 4500,
        category: "Furniture",
        condition: "Good",
        location: "Agra, Uttar Pradesh",
        description: "Sturdy Sheesham wood study desk with 2 storage drawers and ergonomic chair. Selling due to relocation.",
        seller: {
            name: "Mohit Verma",
            phone: "9834567890",
            email: "mohit@ahd.in",
            role: "seller"
        },
        images: [
            "https://images.unsplash.com/photo-1518455027359-f3f8164ba6b7?auto=format&fit=crop&w=1000&q=80"
        ],
        rating: 4.4,
        status: "active",
        createdAt: new Date().toISOString()
    },
    {
        id: "P006",
        name: "Royal Enfield Classic 350",
        price: 145000,
        category: "Vehicles",
        condition: "Good",
        location: "Agra, Uttar Pradesh",
        description: "Classic 350 Gunmetal Grey, single owner, comprehensive insurance, regular authorized service.",
        seller: {
            name: "Neeraj Gupta",
            phone: "9898765432",
            email: "neeraj@ahd.in",
            role: "seller"
        },
        images: [
            "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&w=1000&q=80"
        ],
        rating: 4.9,
        status: "active",
        createdAt: new Date().toISOString()
    }
];

class DataStore {
    constructor() {
        this.files = {
            users: path.join(DATA_DIR, "users.json"),
            products: path.join(DATA_DIR, "products.json"),
            requests: path.join(DATA_DIR, "requests.json"),
            deals: path.join(DATA_DIR, "deals.json"),
            messages: path.join(DATA_DIR, "messages.json")
        };

        this.init();
    }

    init() {
        Object.entries(this.files).forEach(([collection, filePath]) => {
            if (!fs.existsSync(filePath)) {
                let initial = [];
                if (collection === "products") {
                    initial = SEED_PRODUCTS;
                }
                fs.writeFileSync(filePath, JSON.stringify(initial, null, 2), "utf-8");
            }
        });
    }

    read(collection) {
        try {
            const filePath = this.files[collection];
            if (!filePath || !fs.existsSync(filePath)) return [];
            const data = fs.readFileSync(filePath, "utf-8");
            return JSON.parse(data || "[]");
        } catch (error) {
            console.error(`Error reading ${collection}:`, error);
            return [];
        }
    }

    write(collection, data) {
        try {
            const filePath = this.files[collection];
            fs.writeFileSync(filePath, JSON.stringify(data, null, 2), "utf-8");
            return true;
        } catch (error) {
            console.error(`Error writing ${collection}:`, error);
            return false;
        }
    }

    // Password hashing helper
    hashPassword(password, salt) {
        if (!salt) {
            salt = crypto.randomBytes(16).toString("hex");
        }
        const hash = crypto.scryptSync(password, salt, 64).toString("hex");
        return { hash, salt };
    }

    verifyPassword(password, hash, salt) {
        const testHash = crypto.scryptSync(password, salt, 64).toString("hex");
        return testHash === hash;
    }

    // USER METHODS
    findUserByEmailOrPhone(identifier) {
        const users = this.read("users");
        const clean = String(identifier || "").trim().toLowerCase();
        const digits = clean.replace(/\D/g, "");

        return users.find(u => {
            const emailMatch = (u.email || "").toLowerCase() === clean;
            const phoneMatch = digits && (u.phone || "").replace(/\D/g, "") === digits;
            return emailMatch || phoneMatch;
        });
    }

    createUser(userData) {
        const users = this.read("users");
        const existing = this.findUserByEmailOrPhone(userData.email) ||
                         (userData.phone && this.findUserByEmailOrPhone(userData.phone));

        if (existing) {
            throw new Error("User with this email or phone number already exists.");
        }

        const { hash, salt } = this.hashPassword(userData.password);

        const newUser = {
            id: "USR-" + Date.now() + "-" + Math.floor(Math.random() * 1000),
            name: userData.name || userData.fullName || "",
            email: String(userData.email || "").trim().toLowerCase(),
            phone: String(userData.phone || "").replace(/\D/g, ""),
            role: userData.role || "customer",
            location: userData.location || "Agra, Uttar Pradesh",
            passwordHash: hash,
            passwordSalt: salt,
            createdAt: new Date().toISOString()
        };

        users.push(newUser);
        this.write("users", users);

        const { passwordHash, passwordSalt, ...safeUser } = newUser;
        return safeUser;
    }

    authenticateUser(identifier, password, role) {
        const user = this.findUserByEmailOrPhone(identifier);
        if (!user) {
            throw new Error("User not found with this email or phone number.");
        }

        if (role && user.role && user.role !== role && user.role !== "both") {
            throw new Error(`Account exists as '${user.role}'. Please select the correct login option.`);
        }

        let isValid = false;
        if (user.passwordHash && user.passwordSalt) {
            isValid = this.verifyPassword(password, user.passwordHash, user.passwordSalt);
        } else if (user.password) {
            isValid = (user.password === password);
        }

        if (!isValid) {
            throw new Error("Invalid password. Please check your credentials.");
        }

        const token = "AHD_TOKEN_" + Buffer.from(`${user.id}:${Date.now()}`).toString("base64");
        const { passwordHash, passwordSalt, password: _, ...safeUser } = user;
        return { user: safeUser, token };
    }

    updatePassword(identifier, newPassword) {
        const users = this.read("users");
        const user = this.findUserByEmailOrPhone(identifier);
        if (!user) {
            throw new Error("User not found.");
        }

        const { hash, salt } = this.hashPassword(newPassword);
        user.passwordHash = hash;
        user.passwordSalt = salt;
        delete user.password;
        user.updatedAt = new Date().toISOString();

        this.write("users", users);
        return true;
    }

    updateUserProfile(identifier, profileData) {
        const users = this.read("users");
        const clean = String(identifier || "").trim().toLowerCase();
        const digits = clean.replace(/\D/g, "");

        const index = users.findIndex(u => {
            const emailMatch = (u.email || "").toLowerCase() === clean;
            const phoneMatch = digits && (u.phone || "").replace(/\D/g, "") === digits;
            return emailMatch || phoneMatch;
        });

        if (index === -1) {
            throw new Error("User not found in backend.");
        }

        const existing = users[index];
        users[index] = {
            ...existing,
            ...profileData,
            id: existing.id,
            email: existing.email,
            phone: existing.phone,
            passwordHash: existing.passwordHash,
            passwordSalt: existing.passwordSalt,
            updatedAt: new Date().toISOString()
        };

        this.write("users", users);
        const { passwordHash, passwordSalt, password: _, ...safeUser } = users[index];
        return safeUser;
    }

    // PRODUCT METHODS
    getProducts(filters = {}) {
        let products = this.read("products");
        if (filters.category && filters.category !== "All") {
            products = products.filter(p => (p.category || "").toLowerCase() === filters.category.toLowerCase());
        }
        if (filters.search) {
            const q = filters.search.toLowerCase();
            products = products.filter(p =>
                (p.name || "").toLowerCase().includes(q) ||
                (p.description || "").toLowerCase().includes(q) ||
                (p.category || "").toLowerCase().includes(q)
            );
        }
        return products;
    }

    getProductById(id) {
        const products = this.read("products");
        return products.find(p => String(p.id) === String(id));
    }

    createProduct(productData) {
        const products = this.read("products");
        const id = productData.id || ("P" + (Date.now() % 1000000));
        const newProduct = {
            ...productData,
            id: String(id),
            status: "active",
            createdAt: new Date().toISOString()
        };
        products.unshift(newProduct);
        this.write("products", products);
        return newProduct;
    }

    // REQUEST METHODS
    createRequest(requestData) {
        const requests = this.read("requests");
        const requestId = requestData.requestId || ("REQ-" + Date.now());
        const newRequest = {
            ...requestData,
            requestId: String(requestId),
            status: "Pending",
            createdAt: new Date().toISOString()
        };
        requests.unshift(newRequest);
        this.write("requests", requests);
        return newRequest;
    }

    getRequestById(requestId) {
        const requests = this.read("requests");
        return requests.find(r => String(r.requestId) === String(requestId));
    }

    // MATCHING ENGINE
    findMatchesForRequest(requestId) {
        const request = this.getRequestById(requestId);
        if (!request) return [];

        const reqCategory = (request.requirement?.category || "").toLowerCase();
        const reqName = (request.requirement?.product || "").toLowerCase();
        const maxBudget = Number(request.requirement?.budget || request.requirement?.maxBudget || 0);

        const products = this.read("products");

        return products.filter(p => {
            const catMatch = !reqCategory || (p.category || "").toLowerCase().includes(reqCategory) || reqCategory.includes((p.category || "").toLowerCase());
            const nameMatch = !reqName || (p.name || "").toLowerCase().includes(reqName) || (p.description || "").toLowerCase().includes(reqName);
            const budgetMatch = !maxBudget || Number(p.price) <= (maxBudget * 1.15);

            return (catMatch || nameMatch) && (budgetMatch || !maxBudget);
        }).map(p => ({
            ...p,
            matchScore: Math.min(99, Math.floor(70 + Math.random() * 25))
        }));
    }

    // DEALS METHODS
    getDeals(userIdentifier) {
        const deals = this.read("deals");
        if (!userIdentifier) return deals;
        return deals.filter(d =>
            (d.customer?.email === userIdentifier || d.seller?.email === userIdentifier)
        );
    }

    createOrUpdateDeal(dealData) {
        const deals = this.read("deals");
        const dealId = dealData.dealId || ("DEAL-" + Date.now());
        const index = deals.findIndex(d => String(d.dealId) === String(dealId));

        if (index >= 0) {
            deals[index] = { ...deals[index], ...dealData, updatedAt: new Date().toISOString() };
            this.write("deals", deals);
            return deals[index];
        } else {
            const newDeal = {
                ...dealData,
                dealId: String(dealId),
                createdAt: new Date().toISOString()
            };
            deals.unshift(newDeal);
            this.write("deals", deals);
            return newDeal;
        }
    }

    // MESSAGES METHODS
    getMessages(userIdentifier) {
        const messages = this.read("messages");
        if (!userIdentifier) return messages;
        return messages.filter(m => m.sender === userIdentifier || m.receiver === userIdentifier);
    }

    createMessage(msgData) {
        const messages = this.read("messages");
        const newMsg = {
            id: "MSG-" + Date.now(),
            ...msgData,
            createdAt: new Date().toISOString()
        };
        messages.push(newMsg);
        this.write("messages", messages);
        return newMsg;
    }
}

module.exports = new DataStore();
