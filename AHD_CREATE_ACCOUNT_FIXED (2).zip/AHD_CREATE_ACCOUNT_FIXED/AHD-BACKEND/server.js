const express = require("express");
const path = require("path");
const dataStore = require("./dataStore");

// Crash prevention: prevent uncaught errors from stopping the process
process.on("uncaughtException", (err) => {
    console.error("⚠️ Uncaught Exception:", err.message);
});

process.on("unhandledRejection", (reason) => {
    console.error("⚠️ Unhandled Rejection:", reason);
});

const app = express();
const PORT = process.env.PORT || 5000;

/* =========================================================
   MIDDLEWARE (CORS & REQUEST LOGGER & BODY PARSER)
========================================================= */
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");

    if (req.method === "OPTIONS") {
        return res.sendStatus(200);
    }
    next();
});

// Real-time request logging in VS Code terminal
app.use((req, res, next) => {
    const time = new Date().toLocaleTimeString();
    console.log(`[${time}] ${req.method} ${req.url}`);
    next();
});

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Serve frontend static files
const frontendPath = path.join(__dirname, "..");
app.use(express.static(frontendPath));

/* =========================================================
   HEALTH CHECK
========================================================= */
app.get("/api/health", (req, res) => {
    res.json({
        status: "online",
        name: "AHD Marketplace API",
        version: "2.0.0",
        timestamp: new Date().toISOString()
    });
});

/* =========================================================
   AUTH ROUTES
========================================================= */
app.post("/api/auth/register", (req, res) => {
    try {
        const { name, fullName, email, phone, password, role, location } = req.body;

        if (!email && !phone) {
            return res.status(400).json({ error: "Email or phone number is required." });
        }
        if (!password || password.length < 6) {
            return res.status(400).json({ error: "Password must be at least 6 characters." });
        }

        const user = dataStore.createUser({
            name: name || fullName,
            email,
            phone,
            password,
            role: role || "customer",
            location
        });

        const authResult = dataStore.authenticateUser(email || phone, password, role);

        res.status(201).json({
            message: "Account created successfully.",
            user: authResult.user,
            token: authResult.token
        });
    } catch (error) {
        console.error("Register Error:", error.message);
        res.status(400).json({ error: error.message });
    }
});

app.post("/api/auth/login", (req, res) => {
    try {
        const { identifier, password, role } = req.body;

        if (!identifier || !password) {
            return res.status(400).json({ error: "Please enter your email/phone and password." });
        }

        const result = dataStore.authenticateUser(identifier, password, role);
        res.json({
            message: "Login successful.",
            user: result.user,
            token: result.token
        });
    } catch (error) {
        console.error("Login Error:", error.message);
        res.status(401).json({ error: error.message });
    }
});

app.post("/api/auth/update-password", (req, res) => {
    try {
        const { identifier, newPassword } = req.body;
        if (!identifier || !newPassword || newPassword.length < 6) {
            return res.status(400).json({ error: "Valid identifier and min 6-character new password required." });
        }

        dataStore.updatePassword(identifier, newPassword);
        res.json({ message: "Password updated successfully." });
    } catch (error) {
        console.error("Update Password Error:", error.message);
        res.status(400).json({ error: error.message });
    }
});

app.post("/api/auth/profile", (req, res) => {
    try {
        const { email, phone, ...profileData } = req.body;
        const identifier = email || phone;
        if (!identifier) {
            return res.status(400).json({ error: "User identifier (email or phone) is required." });
        }

        const updatedUser = dataStore.updateUserProfile(identifier, profileData);
        res.json({
            message: "Profile updated successfully.",
            user: updatedUser
        });
    } catch (error) {
        console.error("Profile Update Error:", error.message);
        res.status(400).json({ error: error.message });
    }
});

/* =========================================================
   PRODUCTS ROUTES
========================================================= */
app.get("/api/products", (req, res) => {
    try {
        const { search, category } = req.query;
        const products = dataStore.getProducts({ search, category });
        res.json(products);
    } catch (error) {
        console.error("Get Products Error:", error.message);
        res.status(500).json({ error: "Failed to fetch products." });
    }
});

app.get("/api/products/:id", (req, res) => {
    try {
        const product = dataStore.getProductById(req.params.id);
        if (!product) {
            return res.status(404).json({ error: "Product not found." });
        }
        res.json(product);
    } catch (error) {
        console.error("Get Product Error:", error.message);
        res.status(500).json({ error: "Failed to fetch product." });
    }
});

app.post("/api/products", (req, res) => {
    try {
        const { name, price, category } = req.body;
        if (!name || !price) {
            return res.status(400).json({ error: "Product name and price are required." });
        }

        const newProduct = dataStore.createProduct(req.body);
        res.status(201).json({
            message: "Product listed successfully.",
            product: newProduct
        });
    } catch (error) {
        console.error("Create Product Error:", error.message);
        res.status(400).json({ error: error.message });
    }
});

/* =========================================================
   REQUESTS & MATCHES ROUTES
========================================================= */
app.post("/api/requests", (req, res) => {
    try {
        const request = dataStore.createRequest(req.body);
        res.status(201).json({
            message: "Buyer request created successfully.",
            request
        });
    } catch (error) {
        console.error("Create Request Error:", error.message);
        res.status(400).json({ error: error.message });
    }
});

app.get("/api/requests/:id", (req, res) => {
    try {
        const request = dataStore.getRequestById(req.params.id);
        if (!request) {
            return res.status(404).json({ error: "Request not found." });
        }
        res.json(request);
    } catch (error) {
        console.error("Get Request Error:", error.message);
        res.status(500).json({ error: "Failed to fetch request." });
    }
});

app.get("/api/matches/:requestId", (req, res) => {
    try {
        const matches = dataStore.findMatchesForRequest(req.params.requestId);
        res.json({
            requestId: req.params.requestId,
            count: matches.length,
            matches
        });
    } catch (error) {
        console.error("Matches Error:", error.message);
        res.status(500).json({ error: "Failed to find matches." });
    }
});

/* =========================================================
   DEALS & MESSAGES ROUTES
========================================================= */
app.get("/api/deals", (req, res) => {
    try {
        const { user } = req.query;
        const deals = dataStore.getDeals(user);
        res.json(deals);
    } catch (error) {
        console.error("Get Deals Error:", error.message);
        res.status(500).json({ error: "Failed to fetch deals." });
    }
});

app.post("/api/deals", (req, res) => {
    try {
        const deal = dataStore.createOrUpdateDeal(req.body);
        res.json({ message: "Deal saved successfully.", deal });
    } catch (error) {
        console.error("Save Deal Error:", error.message);
        res.status(400).json({ error: error.message });
    }
});

app.get("/api/messages", (req, res) => {
    try {
        const { user } = req.query;
        const messages = dataStore.getMessages(user);
        res.json(messages);
    } catch (error) {
        console.error("Get Messages Error:", error.message);
        res.status(500).json({ error: "Failed to fetch messages." });
    }
});

app.post("/api/messages", (req, res) => {
    try {
        const msg = dataStore.createMessage(req.body);
        res.status(201).json({ message: "Message sent.", data: msg });
    } catch (error) {
        console.error("Send Message Error:", error.message);
        res.status(400).json({ error: error.message });
    }
});

/* =========================================================
   FALLBACK ROUTE & ERROR HANDLING
========================================================= */
app.use((req, res) => {
    const indexPath = path.join(frontendPath, "index.html");
    res.sendFile(indexPath, (err) => {
        if (err && !res.headersSent) {
            res.status(404).send("Page not found");
        }
    });
});

app.use((err, req, res, next) => {
    console.error("Express Global Error:", err.stack || err.message);
    if (!res.headersSent) {
        res.status(500).json({ error: "Internal server error" });
    }
});

app.listen(PORT, "0.0.0.0", () => {
    console.log(`=========================================`);
    console.log(`🚀 AHD Marketplace Backend is Running!`);
    console.log(`📡 URL: http://localhost:${PORT}`);
    console.log(`📡 Alternative: http://127.0.0.1:${PORT}`);
    console.log(`📂 Serving Frontend & REST APIs`);
    console.log(`=========================================`);
});